Table S8 (LORA modules)

TableS8.xlsx and TableS8.tsv are the same tables. 
We included the tsv file because some huge rna3dhub links may become broken in the xlsx format.

PDB - PDB entry
ID - LORA module identifier
SIZE - Module size in residues
STRANDS - Module size in strands
SSE - secondary structure elements involved in the module
SSE_STRANDS - number of strands of each secondary structure element involved in the module
DESCRIPTION - Module descriptive type
RES - Module residues list (rna3dhub link)
RFAM - Rfam family of the RNA chains involved in the module
#DSSR_HBOND - Number of H-bonds annotated with DSSR
DSSR_HBOND - H-bonds annotated with DSSR (rna3dhub link)
#DSSR_ABC - Number of Atom-base capping annotated with DSSR 
DSSR_ABC - Atom-base capping annotated with DSSR (rna3dhub link)
#DSSR_AMINOR - Number of A-minors annotated with DSSR
DSSR_AMINOR - A-minors annotated with DSSR (rna3dhub link)
#DSSR_RIBZIP - Number of Ribose-zippers annotated with DSSR
DSSR_RIBZIP - Ribose-zippers annotated with DSSR (rna3dhub link)
#URSLIB2_BIEBWE - Number of BIE/BWE motifs, annotated with urslib2
URSLIB2_BIEBWE - BIE/BWE motifs, annotated with urslib2 (rna3dhub link)
#URSLIB2_TETRALOOP - Number of Tetraloops, annotated with urslib2
URSLIB2_TETRALOOP - Tetraloops, annotated with urslib2 (rna3dhub link)
#FR3D_BPH - Number of Base-phosphate interactions annotated with FR3D
FR3D_BPH - Base-phosphate interactions annotated with FR3D (rna3dhub link)
#FR3D_BR - Number of Base-ribose interactions annotated with FR3D
FR3D_BR - Base-ribose interactions annotated with FR3D (rna3dhub link)
#DSSR_STACKING - Number of Base stacking annotated with DSSR
DSSR_STACKING - Base stacking annotated with DSSR (rna3dhub link)
#FR3D_STACKING - Number of Base stacking annotated with FR3D
FR3D_STACKING - Base stacking annotated with FR3D (rna3dhub link)
#MCANNOTATE_STACKING - Number of Base stacking annotated with MC-Annotate
MCANNOTATE_STACKING - Base stacking annotated with MC-Annotate (rna3dhub link)
#RNAVIEW_STACKING - Number of Base stacking annotated with RNAView
RNAVIEW_STACKING - Base stacking annotated with RNAView (rna3dhub link)
#DSSR_BP - Number of Base pairs annotated with DSSR
DSSR_BP - Base pairs annotated with DSSR (rna3dhub link)
#FR3D_BP - Number of Base pairs annotated with FR3D 
FR3D_BP - Base pairs annotated with FR3D (rna3dhub link)
#MCANNOTATE_BP - Number of Base pairs annotated with MC-Annotate
MCANNOTATE_BP - Base pairs annotated with MC-Annotate (rna3dhub link)
#RNAVIEW_BP - Number of Base pairs annotated with RNAView
RNAVIEW_BP - Base pairs annotated with RNAView (rna3dhub link)
#CLARNA_BP - Number of Base pairs annotated with ClaRNA with score > 0.5
CLARNA_BP - Base pairs annotated with ClaRNA with score > 0.5 (rna3dhub link)
#CLARNA_STACKING - Number of Base stacking annotated with ClaRNA with score > 0.5
CLARNA_STACKING - Base stacking annotated with ClaRNA with score > 0.5 (rna3dhub link)
#CLARNA_BPH - Number of Base-phosphate interactions annotated with ClaRNA with score > 0.5
CLARNA_BPH - Base-phosphate interactions annotated with ClaRNA with score > 0.5 (rna3dhub link)
#CLARNA_BR - Number of Base-ribose interactions annotated with ClaRNA with score > 0.5
CLARNA_BR - Base-ribose interactions annotated with ClaRNA with score > 0.5 (rna3dhub link)
#CLARNA_OTHER - Number of Other interactions annotated with ClaRNA with score > 0.5
CLARNA_OTHER - Other interactions annotated with ClaRNA with score > 0.5 (rna3dhub link)
#CLARNA_BP_ALL - Number of Base pairs annotated with ClaRNA with any score 
CLARNA_BP_ALL - Base pairs annotated with ClaRNA with any score (rna3dhub link)
#MOTIF1 - Number of Motif1 matches annotated with ARTEM
MOTIF1 - Motif1 matches annotated with ARTEM (rna3dhub link)
#MOTIF2 - Number of Motif2 matches annotated with ARTEM
MOTIF2 - Motif2 matches annotated with ARTEM (rna3dhub link)
#MOTIF3 - Number of Motif3 matches annotated with ARTEM
MOTIF3 - Motif3 matches annotated with ARTEM (rna3dhub link)
#MOTIF4 - Number of Motif4 matches annotated with ARTEM
MOTIF4 - Motif4 matches annotated with ARTEM (rna3dhub link)
#MOTIF5 - Number of Motif5 matches annotated with ARTEM
MOTIF5 - Motif5 matches annotated with ARTEM (rna3dhub link)
#MOTIF6 - Number of Motif6 matches annotated with ARTEM 
MOTIF6 - Motif6 matches annotated with ARTEM (rna3dhub link)
#MOTIF7 - Number of Motif7 matches annotated with ARTEM
MOTIF7 - Motif7 matches annotated with ARTEM (rna3dhub link)
#MOTIF8 - Number of Motif8 matches annotated with ARTEM
MOTIF8 - Motif8 matches annotated with ARTEM (rna3dhub link)
#MOTIF9 - Number of Motif9 matches annotated with ARTEM
MOTIF9 - Motif9 matches annotated with ARTEM (rna3dhub link)
#MOTIF10 - Number of Motif10 matches annotated with ARTEM
MOTIF10 - Motif10 matches annotated with ARTEM (rna3dhub link)
#MOTIF11 - Number of Motif11 matches annotated with ARTEM
MOTIF11 - Motif11 matches annotated with ARTEM (rna3dhub link)
#MOTIF12 - Number of Motif12 matches annotated with ARTEM 
MOTIF12 - Motif12 matches annotated with ARTEM (rna3dhub link)
#MOTIF13 - Number of Motif13 matches annotated with ARTEM
MOTIF13 - Motif13 matches annotated with ARTEM (rna3dhub link)
#MOTIF14 - Number of Motif14 matches annotated with ARTEM 
MOTIF14 - Motif14 matches annotated with ARTEM (rna3dhub link)
#MOTIF15 - Number of Motif15 matches annotated with ARTEM
MOTIF15 - Motif15 matches annotated with ARTEM (rna3dhub link)
#MOTIF16 - Number of Motif16 matches annotated with ARTEM
MOTIF16 - Motif16 matches annotated with ARTEM (rna3dhub link)
#MOTIF17 - Number of Motif17 matches annotated with ARTEM
MOTIF17 - Motif17 matches annotated with ARTEM (rna3dhub link)
#MOTIF18 - Number of Motif18 matches annotated with ARTEM
MOTIF18 - Motif18 matches annotated with ARTEM (rna3dhub link)
#MOTIF19 - Number of Motif19 matches annotated with ARTEM
MOTIF19 - Motif19 matches annotated with ARTEM (rna3dhub link)
#MOTIF20 - Number of Motif20 matches annotated with ARTEM
MOTIF20 - Motif20 matches annotated with ARTEM (rna3dhub link)
#MOTIF21 - Number of Motif21 matches annotated with ARTEM
MOTIF21 - Motif21 matches annotated with ARTEM (rna3dhub link)
#MOTIF22 - Number of Motif22 matches annotated with ARTEM
MOTIF22 - Motif22 matches annotated with ARTEM (rna3dhub link)
#MOTIF23 - Number of Motif23 matches annotated with ARTEM
MOTIF23 - Motif23 matches annotated with ARTEM (rna3dhub link)
#MOTIF24 - Number of Motif24 matches annotated with ARTEM
MOTIF24 - Motif24 matches annotated with ARTEM (rna3dhub link)
#MOTIF25 - Number of Motif25 matches annotated with ARTEM
MOTIF25 - Motif25 matches annotated with ARTEM (rna3dhub link)
#MOTIF26 - Number of Motif26 matches annotated with ARTEM
MOTIF26 - Motif26 matches annotated with ARTEM (rna3dhub link)
#MOTIF27 - Number of Motif27 matches annotated with ARTEM 
MOTIF27 - Motif27 matches annotated with ARTEM (rna3dhub link)
#MOTIF28 - Number of Motif28 matches annotated with ARTEM
MOTIF28 - Motif28 matches annotated with ARTEM (rna3dhub link)
#MOTIF29 - Number of Motif29 matches annotated with ARTEM
MOTIF29 - Motif29 matches annotated with ARTEM (rna3dhub link)
#MOTIF30 - Number of Motif30 matches annotated with ARTEM 
MOTIF30 - Motif30 matches annotated with ARTEM (rna3dhub link)
#MOTIF31 - Number of Motif31 matches annotated with ARTEM
MOTIF31 - Motif31 matches annotated with ARTEM (rna3dhub link)
#MOTIF32 - Number of Motif32 matches annotated with ARTEM
MOTIF32 - Motif32 matches annotated with ARTEM (rna3dhub link)
#MOTIF33 - Number of Motif33 matches annotated with ARTEM
MOTIF33 - Motif33 matches annotated with ARTEM (rna3dhub link)
#MOTIF34 - Number of Motif34 matches annotated with ARTEM
MOTIF34 - Motif34 matches annotated with ARTEM (rna3dhub link)
#MOTIF35 - Number of Motif35 matches annotated with ARTEM
MOTIF35 - Motif35 matches annotated with ARTEM (rna3dhub link)
#MOTIF36 - Number of Motif36 matches annotated with ARTEM
MOTIF36 - Motif36 matches annotated with ARTEM (rna3dhub link)
#MOTIF37 - Number of Motif37 matches annotated with ARTEM
MOTIF37 - Motif37 matches annotated with ARTEM (rna3dhub link)
#MOTIF38 - Number of Motif38 matches annotated with ARTEM
MOTIF38 - Motif38 matches annotated with ARTEM (rna3dhub link)
#MOTIF39 - Number of Motif39 matches annotated with ARTEM
MOTIF39 - Motif39 matches annotated with ARTEM (rna3dhub link)
#MOTIF40 - Number of Motif40 matches annotated with ARTEM 
MOTIF40 - Motif40 matches annotated with ARTEM (rna3dhub link)
#MOTIF41 - Number of Motif41 matches annotated with ARTEM
MOTIF41 - Motif41 matches annotated with ARTEM (rna3dhub link)
#MOTIF42 - Number of Motif42 matches annotated with ARTEM
MOTIF42 - Motif42 matches annotated with ARTEM (rna3dhub link)
#MOTIF43 - Number of Motif43 matches annotated with ARTEM
MOTIF43 - Motif43 matches annotated with ARTEM (rna3dhub link)
#MOTIF44 - Number of Motif44 matches annotated with ARTEM
MOTIF44 - Motif44 matches annotated with ARTEM (rna3dhub link)
#MOTIF45 - Number of Motif45 matches annotated with ARTEM
MOTIF45 - Motif45 matches annotated with ARTEM (rna3dhub link)
