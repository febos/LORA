
mod2mot.tsv
===========
Summary statistics of the derived motifs for each module
Columns:
module - module ID
size - module size in nucleotides
motifs - number of the derived motifs
occurr - number of the derived motifs' hits

size_distr.tsv
==============
Distribution of motifs of different sizes.
Columns:
motif_size - motif size in nucleotides
count - number of the derived motifs of the given motif size

motifs_part1.tsv
================
The table of motifs, part 1, first 600k rows.
Columns:
PDB-ID	- source PDB entry ID
MODULE_ID	- source module ID
MODULE_SIZE	- source module size in nucleotides
MOTIF_ID	- derived motif ID
MOTIF_SIZE	- derived motif size
MOTIF_NUCL	- residues list of the motif
TOTAL	- total number of hits with the given motif
TOTAL_MODULES	- total number of the hits' source modules
OCCURRENCES - description of the hits (format: module-residues-rmsd)

motifs_part2.tsv
================
The table of motifs, part 2, last 556113 rows.
Columns: see description for motifs_part1.tsv.
